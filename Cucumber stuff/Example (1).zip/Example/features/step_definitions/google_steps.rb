Given /^I have opened "([^"]*)"$/ do |url|
        visit url
end

When /^I search for "([^"]*)"$/ do |search|
	fill_in "q", :with => search
end

Then /^I should see "([^"]*)"$/ do |text|
	page.should have_content(text)
end